<?php
/* Template Name:  Pages Update Profile */ 

global $current_user;
//print_r($current_user);
if ( (isset($_POST['biodata_kirim_nonce_field']) && wp_verify_nonce($_POST['biodata_kirim_nonce_field'], 'biodata_kirim_action')) ){
   $_POST['tgl_lahir'] = $_POST['tanggal'] . "-" .$_POST['bulan']. "-" . $_POST['tahun'];

   if(
         $_POST['nama_lengkap']=="" || $_POST['tempat_lahir']=="" || 
         $_POST['tgl_lahir']=="" || $_POST['no_ktp']=="" || 
         $_POST['jenis_kelamin']=="" || $_POST['agama']=="" ||
         $_POST['alamat_rumah']=="" || $_POST['nomor_telepon_hp']=="" || $_POST['email']=""
       ){
     
     $error = "*** Semua masukan harus diisi";
     
   }else{

     $biodata = array(
        'nama_lengkap'=>$_POST['nama_lengkap'],
        'tempat_lahir'=>$_POST['tempat_lahir'],
        'tgl_lahir'=>$_POST['tgl_lahir'],
        'no_ktp'=>$_POST['no_ktp'],
        'jenis_kelamin'=>$_POST['jenis_kelamin'],
        'agama'=>$_POST['agama'],
        'alamat_rumah'=>$_POST['alamat_rumah'],
        'nomor_telepon_hp'=>$_POST['nomor_telepon_hp'],
        'email'=>$_POST['email'],
        );
     //if (!current_user_can('edit_user', $user_id))
     //    return false;
     update_usermeta($current_user->ID, 'biodata_user', json_encode($biodata));
     wp_redirect(OT_URL);
     exit();
     
    }
}


?>
<?php get_header(); ?>
<div id="content"> 
<?php //include(TEMPLATEPATH."/slider.php");?>
<div class="clear1"></div>
<div class="entry">	 
    <div class="post" id="post-profile">
        <form name="updateBiodata" method="post" action="#">
            <h2 class="title">Biodata</h2>
            <!-- = -->
            <p>
                Sebelum memulai tes, lengkapilah data pribadi Anda dengan mengisi form di bawah ini. 
                Biodata Anda akan tersimpan otomatis di database Speedy Avenger dan dijamin kerahasiaannya.
            </p>
            <?php
            if(isset($error)){
               echo "<p class='error'>".$error."</p>";
            }
            ?>
            <?php
            $biodata_user = get_the_author_meta('biodata_user', $current_user->ID);
            $biodata = json_decode($biodata_user, true);
            //print_r($biodata);
            $tgl_lahir = explode("-",$biodata['tgl_lahir']);
            $tanggal = $tgl_lahir[0];
            $bulan = $tgl_lahir[1];
            $tahun = $tgl_lahir[2];
            
            ?>
            <p><div class="grid_3"> Nama Lengkap </div> <div class="grid_8">: <input name="nama_lengkap" type="text" value="<?php echo isset($biodata['nama_lengkap']) ? $biodata['nama_lengkap']:'';?>"></div></p>

            <p><div class="grid_3"> Tempat/Tanggal Lahir </div> <div class="grid_8">: <input name="tempat_lahir" type="text" value="<?php echo isset($biodata['tempat_lahir'])? $biodata['tempat_lahir']:'';?>"> /            
            
            <input name="tanggal" type="text" size="3" value="<?php echo isset($tanggal)? $tanggal:'';?>">
            <select name="bulan">
               <option value="januari">Januari</option>
               <option value="februari">Februari</option>
               <option value="maret">Maret</option>
               <option value="april">April</option>
               <option value="mei">Mei</option>
               <option value="juni">Juni</option>
               <option value="juli">Juli</option>
               <option value="agustus">Agustus</option>
               <option value="september">September</option>
               <option value="oktober">Oktober</option>
               <option value="nopember">Nopember</option>
               <option value="desember">Desember</option>
            </select>
            <input name="tahun" type="text" size="6" value="<?php echo isset($tahun)? $tahun:'';?>">
            
            <!--<input name="tgl_lahir" type="text" value="<?php echo isset($biodata['tgl_lahir'])? $biodata['tgl_lahir']:'';?>">--></div></p>
            
            <p><div class="grid_3"> No KTP </div> <div class="grid_8">: <input name="no_ktp" type="text" value="<?php echo isset($biodata['no_ktp'])? $biodata['no_ktp']:'';?>"></div></p>

            <p><div class="grid_3"> Jenis Kelamin </div> <div class="grid_8">: <select name="jenis_kelamin"><option value="Laki-laki">Laki-laki</option><option value="Perempuan">Perempuan</option></select></div></p>

            <p><div class="grid_3"> Agama </div> <div class="grid_8">: <input name="agama" type="text" value="<?php echo isset($biodata['agama'])? $biodata['agama']:'';?>"></div></p>

            <p><div class="grid_3"> Alamat Rumah </div> <div class="grid_8">: <input name="alamat_rumah" type="text" value="<?php echo isset($biodata['alamat_rumah'])? $biodata['alamat_rumah']:'';?>"></div></p>

            <p><div class="grid_3"> Nomor Telepon / HP </div> <div class="grid_8">: <input name="nomor_telepon_hp" type="text" value="<?php echo isset($biodata['nomor_telepon_hp'])? $biodata['nomor_telepon_hp']:'';?>"></div></p>

            <p><div class="grid_3"> Email </div> <div class="grid_8">: <input name="email" type="text" value="<?php echo isset($biodata['email'])? $biodata['email']:'';?>"></div></p>
<div class="clear"></div>
            <div class="grid_11"><br>
<?php echo '<input name="submit_book_button" id="button" class="botton-primary" value="Simpan" type="submit" >';
            wp_nonce_field('biodata_kirim_action','biodata_kirim_nonce_field');
            ?></div>
        </form>
    </div>
    <div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<?php get_footer(); ?>