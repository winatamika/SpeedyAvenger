<div class="grid_13sidebar">
<div class="sidebar">
 	<div class="index"><?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Index group") ) :endif; ?></div>
    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar") ) :endif; ?>
     <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar1") ) :endif; ?>
    
</div>
</div>