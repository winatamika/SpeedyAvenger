<div class="slider">
<!--?php echo do_shortcode('[nggallery id=1  w=400 h=300 template="3dfluxsliderview"] '); ?-->
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/sliderimg.jpg"  />

</div>
<div class="clear"></div>