<?php get_header(); ?>
<div id="content"> 
<?php include(TEMPLATEPATH."/slider.php");?>
      <?php get_sidebar(); ?>
            <div class="grid_13content">
             <div class="entry">	 
              <h2 class='pagetitle'>Error 404 - Page Not Found</h2>
            </div>
            </div> 
        
        <div class="clear"></div>
</div>


<?php get_footer(); ?>